﻿using Assignment.Contracts.Data.Entities;

namespace Assignment.Contracts.Data.Repositories
{
    public interface IAppRepository : IRepository<App> { }
}