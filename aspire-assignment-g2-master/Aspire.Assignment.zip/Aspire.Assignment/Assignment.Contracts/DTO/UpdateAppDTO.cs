namespace Assignment.Contracts.DTO
{
    public class UpdateAppDTO
    {
        public string Name { get; set; }
        public string Moniker { get; set; }
    }
}   